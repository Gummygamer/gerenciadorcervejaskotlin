package com.example.kotlinbeersearch

import retrofit2.http.GET

interface BeerService {
    @GET("notes")
    fun list()
}